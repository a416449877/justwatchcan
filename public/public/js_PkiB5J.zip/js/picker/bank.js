let bankList= [
    {
    text: '工商银行',
    value: "ICBC"
  }, {
    text: '农业银行',
    value: "ABC"
  },
  {
    text: '招商银行',
    value: "CMB"
  },
  {
    text: '交通银行',
    value: "BCM"
  },
  {
    text: '建设银行',
    value: "CCB"
  },
  {
    text: '民生银行',
    value: "CMBC"
  },
  {
    text: '兴业银行',
    value: "CIB"
  }, {
    text: '中国银行',
    value: "BOC"
  },
  {
    text: '浦发银行',
    value: "SPDB"
  },
  {
    text: '东亚银行',
    value: "HKBEA"
  },
  {
    text: '光大银行',
    value: "CEB"
  },
  {
    text: '华夏银行',
    value: "HXB"
  },
  {
    text: '邮政储蓄银行',
    value: "PSBC"
  },
  {
    text: '平安银行',
    value: "PAB"
  },
  {
    text: '广发银行',
    value: "CGB"
  },
  {
    text: '宁波银行',
    value: "NBCB"
  },
  {
    text: '中信银行',
    value: "CITIC"
  },
  {
    text: '渤海银行',
    value: "CBHB"
  },
  {
    text: '北京银行',
    value: "BOB"
  },
  {
    text: '南京银行',
    value: "NJCB"
  },
  {
    text: '上海银行',
    value: "SHB"
  },
  {
    text: '广州银行',
    value: "GZYH"
  },
  {
    text: '杭州银行',
    value: "HZYH"
  },
  {
    text: '杭州联合农村商业银行',
    value: "HZLHNCSYYH"
  },
];